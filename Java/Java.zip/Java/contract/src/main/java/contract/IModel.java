package contract;

import java.util.Observable;

public interface IModel {

	Observable getObservable();
}
