package contract;

public interface IView {
}
